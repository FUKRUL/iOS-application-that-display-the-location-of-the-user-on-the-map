//
//  ViewController.swift
//  A1_iOS_Sanjay_c0788252
//
//  Created by Khushboo on 26/01/21.
//  Copyright © 2021 Sanjay. All rights reserved.
//

import UIKit
import CoreLocation
import MapKit


class ViewController: UIViewController {
    @IBOutlet weak var MapView: MKMapView!
    @IBOutlet weak var BttnRoute: UIButton!
    
    let LocationManagers = CLLocationManager()
    var LocalArry = [CLLocationCoordinate2D]()
    var name = ["A", "B", "C"]
    fileprivate var Polygon: MKPolygon? = nil
    fileprivate var PolyLine: MKPolyline? = nil
    var currentLocation : CLLocationCoordinate2D?
    var LocalString = " select Your location"
    
    // declare of city latitude and langitude
    override func viewDidLoad() {
        super.viewDidLoad()
        self.BttnRoute.isEnabled = false
        askTOLocation()
        let LongPress = UILongPressGestureRecognizer(target: self, action: #selector(addAnnotation(gestureRecognizer:)))
        LongPress.minimumPressDuration = 1.0
        MapView.addGestureRecognizer(LongPress)
        
        let annotation1 = MKPointAnnotation()
        annotation1.coordinate = CLLocationCoordinate2D(latitude: 40.31239, longitude: -87.0399)
        annotation1.title = "Winsor"
        MapView.addAnnotation(annotation1)
        
        
        let annotation2 = MKPointAnnotation()
        annotation2.coordinate = CLLocationCoordinate2D(latitude: 44.4141, longitude: -73.6892)
        annotation2.title = "torento"
        MapView.addAnnotation(annotation2)
        
        
        let annotation3 = MKPointAnnotation()
        annotation3.coordinate = CLLocationCoordinate2D(latitude: 44.6655, longitude: -77.4032)
        annotation3.title = "otawa"
        MapView.addAnnotation(annotation3)
        
        
    }
    // define fun of route clicking
    @IBAction func routeClick(_ sender: Any) {
        if LocalArry.count >= 3 {
            
            let overlayes = MapView.overlays
            MapView.removeOverlays(overlayes)
            
            self.getRoutes()
        }
        
    }
    fileprivate func askTOLocation() {
        self.LocationManagers.requestAlwaysAuthorization()
        self.LocationManagers.requestWhenInUseAuthorization()
        
        if CLLocationManager.locationServicesEnabled() {
            LocationManagers.delegate = self
            LocationManagers.desiredAccuracy = kCLLocationAccuracyBest
            LocationManagers.startUpdatingLocation()
            
            switch CLLocationManager.authorizationStatus() {
            case .notDetermined, .restricted, .denied:
                
                DispatchQueue.main.async {
                    let Alrt = UIAlertController(title: "Location permission is not allowed", message: nil, preferredStyle: Alerts)
                    Alrt.addAction(UIAlertAction(title: "Ok", style: .default, handler: nil))
                    self.present(Alrt, animated: true, completion: nil)
                }
                
                
            case .authorizedAlways, .authorizedWhenInUse:
                return
            @unknown default:
                return
            }
        }
        MapView.delegate = self
        MapView.mapType = .standard
        MapView.isZoomEnabled = true
        MapView.isScrollEnabled = true
        
        if let Core = MapView.userLocation.location?.coordinate{
            MapView.setCenter(Core, animated: true)
        }
    }
    
    func getRoutes() {
        
        let Padding: CGFloat = 8
        let Requst1 = MKDirections.Request()
        Requst1.source = MKMapItem(placemark: MKPlacemark(coordinate: LocalArry[0], addressDictionary: nil))
        Requst1.destination = MKMapItem(placemark: MKPlacemark(coordinate: LocalArry[1], addressDictionary: nil))
        Requst1.requestsAlternateRoutes = true
        Requst1.transportType = .automobile
        
        let DirectionXY = MKDirections(request: Requst1)
        
        DirectionXY.calculate { [unowned self] response, error in
            guard let route = response?.routes.first else { return }
            
            self.MapView.addOverlay(route.polyline)
            self.MapView.setVisibleMapRect(route.polyline.boundingMapRect, animated: true)
            self.MapView.setVisibleMapRect(
                self.MapView.visibleMapRect.union(
                    route.polyline.boundingMapRect
                ),
                edgePadding: UIEdgeInsets(
                    top: 0,
                    left: Padding,
                    bottom: Padding,
                    right: Padding
                ),
                animated: true
            )
            
        }
        
        let Requst2 = MKDirections.Request()
        Requst2.source = MKMapItem(placemark: MKPlacemark(coordinate: LocalArry[1], addressDictionary: nil))
        Requst2.destination = MKMapItem(placemark: MKPlacemark(coordinate: LocalArry[2], addressDictionary: nil))
        Requst2.requestsAlternateRoutes = true
        Requst2.transportType = .automobile
        
        let DirectionYZ = MKDirections(request: Requst2)
        
        DirectionYZ.calculate { [unowned self] response, error in
            guard let Routes = response?.routes.first else { return }
            
            self.MapView.addOverlay(Routes.polyline)
            self.MapView.setVisibleMapRect(Routes.polyline.boundingMapRect, animated: true)
            self.MapView.setVisibleMapRect(
                self.MapView.visibleMapRect.union(
                    Routes.polyline.boundingMapRect
                ),
                edgePadding: UIEdgeInsets(
                    top: 0,
                    left: Padding,
                    bottom: Padding,
                    right: Padding
                ),
                animated: true
            )
        }
        
        
        let Requst3 = MKDirections.Request()
        Requst3.source = MKMapItem(placemark: MKPlacemark(coordinate: LocalArry[2], addressDictionary: nil))
        Requst3.destination = MKMapItem(placemark: MKPlacemark(coordinate: LocalArry[0], addressDictionary: nil))
        Requst3.requestsAlternateRoutes = true
        Requst3.transportType = .automobile
        
        let DirectionsZ = MKDirections(request: Requst3)
        
        DirectionsZ.calculate { [unowned self] response, error in
            guard let Routes = response?.routes.first else { return }
            
            self.MapView.addOverlay(Routes.polyline)
            self.MapView.setVisibleMapRect(Routes.polyline.boundingMapRect, animated: true)
            self.MapView.setVisibleMapRect(
                self.MapView.visibleMapRect.union(
                    Routes.polyline.boundingMapRect
                ),
                edgePadding : UIEdgeInsets(
                    top : 0,
                    left: Padding,
                    bottom: Padding,
                    right: Padding
                ),
                animated: true
            )
        
        
        
    }
    
      fileprivate func ManagerMarker(_ newCoordinates: CLLocationCoordinate2D) {
        if LocalArry.count > 3 {
            LocalArry.removeAll()
            self.BttnRoute.isEnabled = false
            let overlays = MapView.overlays
            MapView.removeOverlays(overlays)
            
            let anno1 = self.MapView.annotations.filter {$0.title != LocalString}
            MapView.removeAnnotations(anno1)
            
        
        
        var placeInformations = "Not FIND"
        if currentLocation != nil{
            
            let CoordinatesX = CLLocation(latitude: (newCoordinates.latitude), longitude: (newCoordinates.longitude))
            let CoordinatesY = CLLocation(latitude: currentLocation!.latitude, longitude: currentLocation!.longitude)
            let DistnsInMeter = CoordinatesX.distance(from: CoordinatesY)
            let A = Double(round(100*DistnsInMeter)/100)
            placeInformations = "\(A) Meters"
            
        }
        
        
        
        print(LocalArry.count)
        let Annotations = MKPointAnnotation()
        Annotations.coordinate = newCoordinates
        Annotations.title = name[LocalArry.count]
        Annotations.subtitle = placeInformations
        
        
        LocalArry.append(newCoordinates)
        MapView.addAnnotation(Annotations)
        self.MapView.setCenter(newCoordinates, animated: true)
        if LocalArry.count == 3 {
            LocalArry.append(LocalArry[0])
            self.MakePolyline()
                        self.BttnRoute.isEnabled = true
                    }
                }
    @objc func addAnnotation(gestureRecognizer:UIGestureRecognizer){
        if gestureRecognizer.state == UIGestureRecognizer.State.began {
            
            
            let TouchPnt = gestureRecognizer.location(in: MapView)
            let NewCoordinates = MapView.convert(TouchPnt, toCoordinateFrom: MapView)
            
            if !self.isCloseToAnyMarker(givenLoc: NewCoordinates) {
                
                CLGeocoder().reverseGeocodeLocation(CLLocation(latitude: newCoordinates.latitude, longitude: newCoordinates.longitude), completionHandler: {(placemarks, error) -> Void in
                           if error != nil {
                            print("Reverse Geocoder fail and Errors" + (error?.localizedDescription ?? ""))
                               return
                           }

                    if placemarks?.count ?? 0 > 0 {
                        let AB = placemarks![0] as! CLPlacemark
                        if AB.administrativeArea != "ON"{
                            let Alerts = UIAlertController(title: "Selection outside of Ontario province is not allowing", message: nil, preferredStyle: .alert)
                            Alerts.addAction(UIAlertAction(title: "Ok", style: .default, handler: nil))
                            self.present(Alerts, animated: true, completion: nil)
                            return
                        }
                        else{
                            self.ManagerMarkers(NewCoordinates)
                        }
                       }
                       else {
                        let Alerts = UIAlertController(title: "Problems also with Getting Data", message: nil, preferredStyle: .alert)
                        Alerts.addAction(UIAlertAction(title: "Ok", style: .default, handler: nil))
                        self.present(Alerts, animated: true, completion: nil)
                       }
                   })
            }
            
            
        }
    }
    //define functions of making polylines
    func MakePolyline() {
        
        let PolyLines = MKPolyline(coordinates: LocalArry, count: LocalArry.count)
        self.PolyLine = PolyLines
        
        let Polygons = MKPolygon(coordinates: &LocalArry, count: LocalArry.count)
        self.Polygon = Polygons
        
        MapView.addOverlays([PolyLines,Polygons])
        
    }
    //define functios of makers
    func isCloserToAnyMarkers(givenLoc:CLLocationCoordinate2D) -> Bool {
        
        for locals in LocalArry{
            let CoordinatesX = CLLocation(latitude: givenLoc.latitude, longitude: givenLoc.longitude)
            let CoordinatesY = CLLocation(latitude: locals.latitude, longitude: locals.longitude)
            let DistanceInMeters = CoordinatesX.distance(from: CoordinatesY)
            
            if DistanceInMeters < 60{
                return true
            }
        }
        
        return false
    }
    
}

      extension ViewController : CLLocationManagerDelegate,MKMapViewDelegate {
    
    func LocationManager(_ manager: CLLocationManager, didUpdateLocations
        locations: [CLLocation]) {
        let locValue:CLLocationCoordinate2D = manager.location!.coordinate
        self.currentLocation = locValue
        
        MapView.mapType = MKMapType.standard
        
        let Span = MKCoordinateSpan(latitudeDelta: 0.05, longitudeDelta: 0.05)
        let Region = MKCoordinateRegion(center: locValue, span: Span)
        MapView.setRegion(Region, animated: true)
        
        let Annotations = MKPointAnnotation()
        Annotations.coordinate = locValue
        Annotations.title = LocalString
        
        
        MapView.addAnnotation(Annotations)
    }
    
    func MapViews(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
        
        let identy = "city"
        
        
        var AnnotationViews = mapView.dequeueReusableAnnotationView(withIdentifier: identy)
        
        if AnnotationViews == nil {
            
            AnnotationViews = MKPinAnnotationView(annotation: annotation, reuseIdentifier: identy)
            AnnotationViews?.canShowCallout = true
            
            
        } else {
            
            AnnotationViews?.annotation = annotation
        }
        
        return AnnotationViews
    }
    
    func MapViews(_ mapView: MKMapView, rendererFor overlay: MKOverlay) -> MKOverlayRenderer {
        if overlay.isKind(of: MKPolyline.self){
            let PolylineRendar = MKPolylineRenderer(overlay: overlay)
            PolylineRendar.fillColor = UIColor.green
            PolylineRendar.strokeColor = UIColor.green
            PolylineRendar.lineWidth = 8
            
            return PolylineRendar
        }
        else if overlay.isKind(of: MKPolygon.self){
            let Renderar = MKPolygonRenderer(polygon: Polygon!)
            Renderar.fillColor = UIColor.red.withAlphaComponent(0.5)
            return Renderar
        }
        return MKOverlayRenderer(overlay: overlay)
    }
 
}
    }
